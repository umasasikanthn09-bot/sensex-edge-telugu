"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { auth } from "../admin/lib/firebase";
import { signInWithEmailAndPassword } from "firebase/auth";

export default function MemberLoginPage() {

  const router = useRouter();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");


  const handleLogin = async () => {

  try {

    await signInWithEmailAndPassword(
      auth,
      email,
      password
    );

    localStorage.setItem("memberLogin", "true");

    router.push("/premium");

  } catch (error: any) {

    console.log(error);
    alert(error.code + "\n" + error.message);

  }

};

  return (
    <main className="min-h-screen bg-black text-white flex items-center justify-center">

      <div className="bg-gray-900 border border-yellow-500 rounded-2xl p-8 w-full max-w-md">

        <h1 className="text-3xl font-bold text-yellow-400 text-center mb-6">
          ⭐ Member Login
        </h1>


        <input
          type="email"
          placeholder="Email"
          className="w-full p-3 mb-4 rounded bg-black border border-gray-600"
          value={email}
          onChange={(e)=>setEmail(e.target.value)}
        />


        <input
          type="password"
          placeholder="Password"
          className="w-full p-3 mb-6 rounded bg-black border border-gray-600"
          value={password}
          onChange={(e)=>setPassword(e.target.value)}
        />


        <button
          onClick={handleLogin}
          className="w-full bg-yellow-400 text-black font-bold py-3 rounded-xl"
        >
          Login
        </button>


      </div>

    </main>
  );
}