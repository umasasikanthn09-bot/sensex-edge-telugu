"use client";

import { useState } from "react";
import { auth } from "../admin/lib/firebase";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { useRouter } from "next/navigation";

export default function RegisterPage() {

  const router = useRouter();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleRegister = async () => {

    try {

      await createUserWithEmailAndPassword(
        auth,
        email,
        password
      );

      alert("✅ Account Created Successfully");

      router.push("/member-login");

    } catch (error:any) {

      alert(error.message);

    }

  };


  return (
    <main className="min-h-screen bg-black text-white flex items-center justify-center">

      <div className="bg-gray-900 border border-yellow-500 rounded-2xl p-8 w-full max-w-md">

        <h1 className="text-3xl font-bold text-yellow-400 text-center mb-6">
          ⭐ Create Member Account
        </h1>


        <input
          type="text"
          placeholder="Your Name"
          className="w-full p-3 mb-4 rounded bg-black border border-gray-600"
          value={name}
          onChange={(e)=>setName(e.target.value)}
        />


        <input
          type="email"
          placeholder="Email"
          className="w-full p-3 mb-4 rounded bg-black border border-gray-600"
          value={email}
          onChange={(e)=>setEmail(e.target.value)}
        />


        <input
          type="password"
          placeholder="Create Password"
          className="w-full p-3 mb-6 rounded bg-black border border-gray-600"
          value={password}
          onChange={(e)=>setPassword(e.target.value)}
        />


        <button
          onClick={handleRegister}
          className="w-full bg-yellow-400 text-black font-bold py-3 rounded-xl"
        >
          Create Account
        </button>


      </div>

    </main>
  );
}