"use client";

import { useState } from "react";
import { db } from "../admin/lib/firebase";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";

export default function JoinPremium() {

  const [fullName, setFullName] = useState("");
  const [mobile, setMobile] = useState("");
  const [email, setEmail] = useState("");
  const [transactionId, setTransactionId] = useState("");
  const [screenshot, setScreenshot] = useState<File | null>(null);

  const submitPaymentRequest = async () => {
    if (!fullName || !mobile || !email || !transactionId) {
  alert("⚠ Please fill all required fields.");
  return;
}
  try {
    await addDoc(collection(db, "paymentRequests"), {
      fullName,
      mobile,
      email,
      transactionId,
      status: "Pending",
      createdAt: serverTimestamp(),
    });

    alert("✅ Payment Request Submitted Successfully!");

    setFullName("");
    setMobile("");
    setEmail("");
    setTransactionId("");
    setScreenshot(null);

  } catch (error) {
    console.error(error);
    alert("❌ Failed to Submit Request");
  }
};

  return (
    <main className="min-h-screen bg-black text-white py-6 px-4">

      <div className="max-w-5xl mx-auto bg-gray-900 border border-yellow-500 rounded-2xl p-6">

        <h1 className="text-4xl font-black text-yellow-400 text-center">
          ⭐ Premium Membership
        </h1>

        <h2 className="text-center text-5xl font-black text-white mt-4">
          ₹999
          <span className="text-xl text-gray-400">
            {" "} / Month
          </span>
        </h2>

        <p className="text-center mt-3 text-gray-300">
          Complete the payment using any UPI App
        </p>

        <div className="grid md:grid-cols-2 gap-8 mt-8 items-center">

          {/* QR */}

          <div className="text-center">

            <img
              src="/qr.png"
              alt="UPI QR"
              className="w-56 mx-auto rounded-xl border-4 border-yellow-500"
            />

            <p className="mt-3 text-gray-400">
              Scan QR Code
            </p>

          </div>

          {/* UPI */}

          <div className="bg-black rounded-xl border border-gray-700 p-5">

            <p className="text-gray-400 mb-3">
              UPI ID
            </p>

            <div className="flex items-center justify-between gap-3 flex-wrap">

              <span className="text-lg font-bold text-green-400 break-all">
                umasasikanthn04@okhdfcbank
              </span>

              <button
                onClick={() => {
                  navigator.clipboard.writeText("umasasikanthn04@okhdfcbank");
                  alert("✅ UPI ID Copied Successfully!");
                }}
                className="bg-green-500 hover:bg-green-400 text-black font-bold px-4 py-2 rounded-lg"
              >
                📋 Copy
              </button>

            </div>

          </div>

        </div>

                {/* Member Details */}

        <div className="grid md:grid-cols-2 gap-4 mt-8">

          <input
            type="text"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            placeholder="👤 Full Name"
            className="w-full p-4 rounded-xl bg-black border border-gray-600 placeholder-gray-400"
          />

          <input
            type="tel"
            value={mobile}
            onChange={(e) => setMobile(e.target.value)}
            placeholder="📱 Mobile Number"
            className="w-full p-4 rounded-xl bg-black border border-gray-600 placeholder-gray-400"
          />

          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="📧 Email Address"
            className="w-full p-4 rounded-xl bg-black border border-gray-600 placeholder-gray-400"
          />

          <input
            type="text"
            value={transactionId}
            onChange={(e) => setTransactionId(e.target.value)}
            placeholder="💳 Transaction ID"
            className="w-full p-4 rounded-xl bg-black border border-gray-600 placeholder-gray-400"
          />

        </div>

                {/* Screenshot */}

        <div className="mt-6">

          <input
            type="file"
            accept="image/*"
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                setScreenshot(e.target.files[0]);
              }
            }}
            className="w-full p-3 rounded-xl bg-black border border-gray-600
            file:bg-yellow-400 file:text-black
            file:font-bold file:border-0
            file:px-4 file:py-2
            file:rounded-lg"
          />

        </div>

        {/* Submit */}

       <button
  onClick={submitPaymentRequest}
  className="w-full mt-6 bg-yellow-400 hover:bg-yellow-300 text-black font-bold py-4 rounded-xl"
>
  ✅ Submit Payment Request
</button>

      </div>

    </main>
  );
}