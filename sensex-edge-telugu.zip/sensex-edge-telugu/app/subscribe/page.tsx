export default function Subscribe() {
  return (
    <main className="min-h-screen bg-black text-white p-8">

      <div className="max-w-4xl mx-auto">

        <h1 className="text-5xl font-black text-yellow-400 text-center mb-10">
          ⭐ Premium Membership
        </h1>

        <div className="bg-gray-900 border border-yellow-500 rounded-2xl p-10 text-center">

          <h2 className="text-3xl font-bold text-yellow-400 mb-6">
            Sensex Edge Telugu Premium Levels
          </h2>
          <div className="mt-6">
  <h3 className="text-4xl font-black text-white">
    ₹999 <span className="text-xl text-gray-400">/ Month</span>
  </h3>
</div>

          <p className="text-gray-300 text-lg leading-8">
            Get access to exclusive Sensex Options Intraday Levels,
            Support & Resistance, CE & PE levels and daily market analysis.
          </p>

          <div className="mt-8 text-left space-y-4 text-lg">

            <p>✅ Today's Sensex Options Levels</p>
            <p>✅ Support & Resistance Zones</p>
            <p>✅ CE / PE Trading Levels</p>
            <p>✅ Daily Market Analysis</p>
            <p>✅ Telugu Trading Guidance</p>

          </div>

          <button
            className="mt-10 bg-yellow-400 text-black px-10 py-4 rounded-xl font-bold text-xl hover:bg-yellow-300 transition"
          >
            💳 Pay Now
          </button>

        </div>

      </div>

    </main>
  );
}