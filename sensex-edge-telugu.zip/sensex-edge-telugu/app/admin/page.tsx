"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";

import { db } from "./lib/firebase";

import {
  doc,
  setDoc,
  collection,
  getDocs,
  updateDoc,
} from "firebase/firestore";

export default function AdminPage() {

  const router = useRouter();

  useEffect(() => {

    const login = localStorage.getItem("adminLogin");

    if (login !== "true") {
      router.push("/login");
      return;
    }

    loadPaymentRequests();

  }, []);

  const [date, setDate] = useState("");
  const [updatedTime, setUpdatedTime] = useState("");
  const [sensexSpot, setSensexSpot] = useState("");

  const [supportLevel, setSupportLevel] = useState("");
  const [supportTarget1, setSupportTarget1] = useState("");
  const [supportTarget2, setSupportTarget2] = useState("");

  const [resistanceLevel, setResistanceLevel] = useState("");
  const [resistanceTarget1, setResistanceTarget1] = useState("");
  const [resistanceTarget2, setResistanceTarget2] = useState("");

  const [ceSupport1, setCeSupport1] = useState("");
  const [ceSupport2, setCeSupport2] = useState("");
  const [ceResistance1, setCeResistance1] = useState("");
  const [ceResistance2, setCeResistance2] = useState("");

  const [peSupport1, setPeSupport1] = useState("");
  const [peSupport2, setPeSupport2] = useState("");
  const [peResistance1, setPeResistance1] = useState("");
  const [peResistance2, setPeResistance2] = useState("");

  const [result1, setResult1] = useState("");
  const [result2, setResult2] = useState("");
  const [result3, setResult3] = useState("");

  const [paymentRequests, setPaymentRequests] = useState<any[]>([]);

  const loadPaymentRequests = async () => {

  const snapshot = await getDocs(
    collection(db, "paymentRequests")
  );

  const list: any[] = [];

  snapshot.forEach((doc) => {

    list.push({
      id: doc.id,
      ...doc.data(),
    });

  });

  setPaymentRequests(list);

};

const approveMember = async (id: string) => {

  await updateDoc(doc(db, "paymentRequests", id), {
    status: "Approved",
  });

  alert("✅ Member Approved");

  loadPaymentRequests();

};

const rejectMember = async (id: string) => {

  await updateDoc(doc(db, "paymentRequests", id), {
    status: "Rejected",
  });

  alert("❌ Member Rejected");

  loadPaymentRequests();

};

const uploadImage = async (file: File, imageNumber: number) => {

  const formData = new FormData();

  formData.append("file", file);

  formData.append(
    "upload_preset",
    "sensex-results"
  );

  try {

    const response = await fetch(
      "https://api.cloudinary.com/v1_1/k0174nam/image/upload",
      {
        method: "POST",
        body: formData,
      }
    );

    const data = await response.json();

    if (imageNumber === 1) {
      setResult1(data.secure_url);
      localStorage.setItem("result1", data.secure_url);
    }

    if (imageNumber === 2) {
      setResult2(data.secure_url);
      localStorage.setItem("result2", data.secure_url);
    }

    if (imageNumber === 3) {
      setResult3(data.secure_url);
      localStorage.setItem("result3", data.secure_url);
    }

    alert("✅ Image Uploaded Successfully");

  } catch (error) {

    console.error(error);

    alert("❌ Image Upload Failed");

  }

};

const clearForm = async () => {

  setDate("");
  setUpdatedTime("");
  setSensexSpot("");

  setSupportLevel("");
  setSupportTarget1("");
  setSupportTarget2("");

  setResistanceLevel("");
  setResistanceTarget1("");
  setResistanceTarget2("");

  setCeSupport1("");
  setCeSupport2("");
  setCeResistance1("");
  setCeResistance2("");

  setPeSupport1("");
  setPeSupport2("");
  setPeResistance1("");
  setPeResistance2("");

  const img1 = localStorage.getItem("result1") || "";
  const img2 = localStorage.getItem("result2") || "";
  const img3 = localStorage.getItem("result3") || "";

  await setDoc(doc(db, "premium", "today"), {

    date: "",
    updatedTime: "",
    sensexSpot: "",

    supportLevel: "",
    supportTarget1: "",
    supportTarget2: "",

    resistanceLevel: "",
    resistanceTarget1: "",
    resistanceTarget2: "",

    ceSupport1: "",
    ceSupport2: "",
    ceResistance1: "",
    ceResistance2: "",

    peSupport1: "",
    peSupport2: "",
    peResistance1: "",
    peResistance2: "",

    result1: img1,
    result2: img2,
    result3: img3,

  });

  alert("✅ All Levels Cleared");

};


const saveLevels = async () => {

  try {

    await setDoc(doc(db, "premium", "today"), {

      date,
      updatedTime,
      sensexSpot,

      supportLevel,
      supportTarget1,
      supportTarget2,

      resistanceLevel,
      resistanceTarget1,
      resistanceTarget2,

      ceSupport1,
      ceSupport2,
      ceResistance1,
      ceResistance2,

      peSupport1,
      peSupport2,
      peResistance1,
      peResistance2,

      result1: localStorage.getItem("result1") || "",
      result2: localStorage.getItem("result2") || "",
      result3: localStorage.getItem("result3") || "",

    });

    alert("✅ Today's Levels Saved Successfully!");

  } catch (error: any) {

    console.error(error);

    alert(error.message);

  }

};

return (

  <main className="min-h-screen bg-black text-white p-8">

    <div className="max-w-6xl mx-auto">

      <h1 className="text-4xl font-black text-yellow-400 text-center mb-10">
        Sensex Edge Telugu - Admin Dashboard
      </h1>

            {/* Admin Navigation */}

      <div className="flex justify-between items-center mb-8">

        <nav className="flex gap-6">

          <a href="/" className="text-white hover:text-yellow-400">
            🏠 Home
          </a>

          <a href="/admin" className="text-white hover:text-yellow-400">
            🔐 Admin
          </a>

          <a href="/premium" className="text-white hover:text-yellow-400">
            ⭐ Premium
          </a>

          <button
            onClick={() => {
              localStorage.removeItem("adminLogin");
              window.location.href = "/login";
            }}
            className="text-red-400 hover:text-red-600"
          >
            🚪 Logout
          </button>

        </nav>

      </div>

      <div className="bg-gray-900 border border-yellow-500 rounded-2xl p-8">

        <h2 className="text-3xl font-bold text-yellow-400 mb-8">
          Today's Market Details
        </h2>

        <div className="grid md:grid-cols-3 gap-6">
        
        return (

  <main className="min-h-screen bg-black text-white p-8">

    <div className="max-w-6xl mx-auto">

      <h1 className="text-4xl font-black text-yellow-400 text-center mb-10">
        Sensex Edge Telugu - Admin Dashboard
      </h1>

      {/* Admin Navigation */}

      <div className="flex justify-between items-center mb-8">

        <nav className="flex gap-6">

          <a href="/" className="text-white hover:text-yellow-400">
            🏠 Home
          </a>

          <a href="/admin" className="text-white hover:text-yellow-400">
            🔐 Admin
          </a>

          <a href="/premium" className="text-white hover:text-yellow-400">
            ⭐ Premium
          </a>

          <button
            onClick={() => {
              localStorage.removeItem("adminLogin");
              window.location.href = "/login";
            }}
            className="text-red-400 hover:text-red-600"
          >
            🚪 Logout
          </button>

        </nav>

      </div>

      <div className="bg-gray-900 border border-yellow-500 rounded-2xl p-8">

        <h2 className="text-3xl font-bold text-yellow-400 mb-8">
          Today's Market Details
        </h2>

        <div className="grid md:grid-cols-3 gap-6">
          
          <div>
  <label className="block text-yellow-400 mb-2">
    Date
  </label>

  <input
    type="date"
    value={date}
    onChange={(e) => setDate(e.target.value)}
    className="w-full p-3 rounded-lg bg-black border border-gray-600"
  />
</div>

<div>
  <label className="block text-yellow-400 mb-2">
    Updated Time
  </label>

  <input
    type="time"
    value={updatedTime}
    onChange={(e) => setUpdatedTime(e.target.value)}
    className="w-full p-3 rounded-lg bg-black border border-gray-600"
  />
</div>

<div>
  <label className="block text-yellow-400 mb-2">
    Sensex Spot
  </label>

  <input
    type="text"
    value={sensexSpot}
    onChange={(e) => setSensexSpot(e.target.value)}
    placeholder="Enter Sensex Spot"
    className="w-full p-3 rounded-lg bg-black border border-gray-600"
  />
</div>

</div>

<hr className="my-10 border-gray-700" />

<h2 className="text-3xl font-bold text-yellow-400 mb-8">
  Results Screenshots
</h2>

<div className="grid md:grid-cols-3 gap-6">
  
  <div className="bg-black border border-green-500 rounded-xl p-6">

  <h3 className="text-xl text-green-400 font-bold mb-4">
    Screenshot 1
  </h3>

  <input
    type="file"
    accept="image/*"
    onChange={(e) =>
      e.target.files &&
      uploadImage(e.target.files[0], 1)
    }
    className="w-full"
  />

</div>

<div className="bg-black border border-yellow-500 rounded-xl p-6">

  <h3 className="text-xl text-yellow-400 font-bold mb-4">
    Screenshot 2
  </h3>

  <input
    type="file"
    accept="image/*"
    onChange={(e) =>
      e.target.files &&
      uploadImage(e.target.files[0], 2)
    }
    className="w-full"
  />

</div>

<div className="bg-black border border-red-500 rounded-xl p-6">

  <h3 className="text-xl text-red-400 font-bold mb-4">
    Screenshot 3
  </h3>

  <input
    type="file"
    accept="image/*"
    onChange={(e) =>
      e.target.files &&
      uploadImage(e.target.files[0], 3)
    }
    className="w-full"
  />

</div>

</div>

<hr className="my-10 border-gray-700" />

<h2 className="text-3xl font-bold text-yellow-400 mb-8">
  Sensex Index Levels
</h2>

<div className="grid md:grid-cols-2 gap-8">

  <div className="bg-black border border-green-500 rounded-xl p-6">

  <h3 className="text-2xl text-green-400 font-bold mb-5">
    Support Side
  </h3>

  <input
    type="text"
    placeholder="Support Level"
    value={supportLevel}
    onChange={(e) => setSupportLevel(e.target.value)}
    className="w-full p-3 mb-4 rounded-lg bg-gray-900 border border-gray-600"
  />

  <input
    type="text"
    placeholder="Target 1"
    value={supportTarget1}
    onChange={(e) => setSupportTarget1(e.target.value)}
    className="w-full p-3 mb-4 rounded-lg bg-gray-900 border border-gray-600"
  />

  <input
    type="text"
    placeholder="Target 2"
    value={supportTarget2}
    onChange={(e) => setSupportTarget2(e.target.value)}
    className="w-full p-3 rounded-lg bg-gray-900 border border-gray-600"
  />

</div>

<div className="bg-black border border-red-500 rounded-xl p-6">

  <h3 className="text-2xl text-red-400 font-bold mb-5">
    Resistance Side
  </h3>

  <input
    type="text"
    placeholder="Resistance Level"
    value={resistanceLevel}
    onChange={(e) => setResistanceLevel(e.target.value)}
    className="w-full p-3 mb-4 rounded-lg bg-gray-900 border border-gray-600"
  />

  <input
    type="text"
    placeholder="Target 1"
    value={resistanceTarget1}
    onChange={(e) => setResistanceTarget1(e.target.value)}
    className="w-full p-3 mb-4 rounded-lg bg-gray-900 border border-gray-600"
  />

  <input
    type="text"
    placeholder="Target 2"
    value={resistanceTarget2}
    onChange={(e) => setResistanceTarget2(e.target.value)}
    className="w-full p-3 rounded-lg bg-gray-900 border border-gray-600"
  />

</div>

</div>

<hr className="my-10 border-gray-700" />

<h2 className="text-3xl font-bold text-green-400 mb-8">
  CE Levels
</h2>

<div className="grid md:grid-cols-2 gap-8">

  <div className="bg-black border border-green-500 rounded-xl p-6">

  <h3 className="text-yellow-400 text-xl font-bold mb-5">
    Support Levels
  </h3>

  <input
    type="text"
    placeholder="Support 1"
    value={ceSupport1}
    onChange={(e) => setCeSupport1(e.target.value)}
    className="w-full p-3 mb-4 rounded-lg bg-gray-900 border border-gray-600"
  />

  <input
    type="text"
    placeholder="Support 2"
    value={ceSupport2}
    onChange={(e) => setCeSupport2(e.target.value)}
    className="w-full p-3 rounded-lg bg-gray-900 border border-gray-600"
  />

</div>

<div className="bg-black border border-red-500 rounded-xl p-6">

  <h3 className="text-yellow-400 text-xl font-bold mb-5">
    Resistance Levels
  </h3>

  <input
    type="text"
    placeholder="Resistance 1"
    value={ceResistance1}
    onChange={(e) => setCeResistance1(e.target.value)}
    className="w-full p-3 mb-4 rounded-lg bg-gray-900 border border-gray-600"
  />

  <input
    type="text"
    placeholder="Resistance 2"
    value={ceResistance2}
    onChange={(e) => setCeResistance2(e.target.value)}
    className="w-full p-3 rounded-lg bg-gray-900 border border-gray-600"
  />

</div>

</div>

<hr className="my-10 border-gray-700" />

<h2 className="text-3xl font-bold text-red-400 mb-8">
  PE Levels
</h2>

<div className="grid md:grid-cols-2 gap-8">

  <div className="bg-black border border-green-500 rounded-xl p-6">

  <h3 className="text-yellow-400 text-xl font-bold mb-5">
    Support Levels
  </h3>

  <input
    type="text"
    placeholder="Support 1"
    value={peSupport1}
    onChange={(e) => setPeSupport1(e.target.value)}
    className="w-full p-3 mb-4 rounded-lg bg-gray-900 border border-gray-600"
  />

  <input
    type="text"
    placeholder="Support 2"
    value={peSupport2}
    onChange={(e) => setPeSupport2(e.target.value)}
    className="w-full p-3 rounded-lg bg-gray-900 border border-gray-600"
  />

</div>

<div className="bg-black border border-red-500 rounded-xl p-6">

  <h3 className="text-yellow-400 text-xl font-bold mb-5">
    Resistance Levels
  </h3>

  <input
    type="text"
    placeholder="Resistance 1"
    value={peResistance1}
    onChange={(e) => setPeResistance1(e.target.value)}
    className="w-full p-3 mb-4 rounded-lg bg-gray-900 border border-gray-600"
  />

  <input
    type="text"
    placeholder="Resistance 2"
    value={peResistance2}
    onChange={(e) => setPeResistance2(e.target.value)}
    className="w-full p-3 rounded-lg bg-gray-900 border border-gray-600"
  />

</div>

</div>

<hr className="my-10 border-gray-700" />

<div className="grid md:grid-cols-3 gap-6">

  <button
  onClick={clearForm}
  className="bg-gray-700 hover:bg-gray-600 rounded-xl p-4 text-white transition"
>
  <div className="text-3xl mb-2">🗑</div>
  <h3 className="text-2xl font-bold">Clear Form</h3>
</button>

<button
  onClick={() => {
    localStorage.setItem("adminPreview", "true");
    window.open("/premium", "_blank");
  }}
  className="bg-blue-600 hover:bg-blue-500 rounded-xl p-4 text-white transition"
>
  <div className="text-3xl mb-2">👁</div>
  <h3 className="text-lg font-bold">Preview Premium</h3>
</button>

<button
  onClick={saveLevels}
  className="bg-yellow-400 hover:bg-yellow-300 rounded-xl p-4 text-black transition"
>
  <div className="text-3xl mb-2">💾</div>
  <h3 className="text-lg font-black">Save Today's Levels</h3>
</button>

</div>

<div className="mt-10 bg-gray-900 border border-yellow-500 rounded-2xl p-6">

  <h2 className="text-3xl font-bold text-yellow-400 mb-6">
    💳 Payment Requests
  </h2>

  <div className="overflow-x-auto">

    <table className="w-full">

      <thead className="bg-yellow-400 text-black">
        <tr>
          <th className="p-4">Name</th>
          <th className="p-4">Mobile</th>
          <th className="p-4">Email</th>
          <th className="p-4">Txn ID</th>
          <th className="p-4">Status</th>
          <th className="p-4">Action</th>
        </tr>
      </thead>

      <tbody>

        {paymentRequests.map((item) => (

          <tr
            key={item.id}
            className="border-b border-gray-700 text-center hover:bg-gray-800"
          >
            <td className="p-4">{item.fullName}</td>
            <td className="p-4">{item.mobile}</td>
            <td className="p-4">{item.email}</td>
            <td className="p-4">{item.transactionId}</td>

            <td className="p-4">
              <span className="bg-orange-500 px-4 py-2 rounded-full font-bold">
                {item.status}
              </span>
            </td>

            <td className="p-4">

              <div className="flex justify-center gap-2">

                <button
                  onClick={() => approveMember(item.id)}
                  className="bg-green-500 hover:bg-green-400 text-white px-3 py-2 rounded-lg"
                >
                  ✅
                </button>

                <button
                  onClick={() => rejectMember(item.id)}
                  className="bg-red-500 hover:bg-red-400 text-white px-3 py-2 rounded-lg"
                >
                  ❌
                </button>

              </div>

            </td>

          </tr>

        ))}

      </tbody>

    </table>

  </div>

</div>

</div>

</main>

);

}